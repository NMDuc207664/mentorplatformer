import React from 'react';
import SessionManagementCard from '../../components/feature/SessionManagementCard';

const SessionManagement: React.FC = () => {
    return <SessionManagementCard />;
};

export default SessionManagement;