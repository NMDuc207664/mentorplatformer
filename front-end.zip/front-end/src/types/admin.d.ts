import { EnumType } from "./commonType";

export interface admin {
  id: number;
  name: string;
  role: EnumType;
}
