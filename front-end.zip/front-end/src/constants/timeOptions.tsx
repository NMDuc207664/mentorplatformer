export const startTimeOptions = ["06:00", "07:00", "08:00", "09:00", "10:00"];
export const endTimeOptions = ["16:00", "17:00", "18:00", "19:00", "20:00"];
