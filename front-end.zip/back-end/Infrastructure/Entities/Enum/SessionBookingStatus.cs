﻿namespace Infrastructure.Entities.Enum
{
    public class SessionBookingStatus : EnumType
    {
        public SessionBookingStatus()
        {
        }
    }
}
