namespace Infrastructure.Entities.Enum
{
    public class LearningStyle : EnumType
    {

        public LearningStyle() { }
    }
}