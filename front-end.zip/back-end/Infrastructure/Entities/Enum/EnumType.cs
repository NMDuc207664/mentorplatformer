namespace Infrastructure.Entities.Enum
{
    public class EnumType
    {
        public required int Id { get; set; }
        public required string Name { get; set; }
    }
}
