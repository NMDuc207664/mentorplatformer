﻿using Infrastructure.Entities.Enum;

namespace Infrastructure.Entities
{
    public class Role : EnumType
    {
        public Role()
        {
        }
    }
}