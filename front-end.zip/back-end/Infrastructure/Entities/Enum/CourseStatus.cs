namespace Infrastructure.Entities.Enum
{
    public class CourseStatus : EnumType
    {
        public CourseStatus() { }
    }
}
