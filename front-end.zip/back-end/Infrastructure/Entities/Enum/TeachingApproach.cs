namespace Infrastructure.Entities.Enum
{
    public class TeachingApproach : EnumType
    {
        public TeachingApproach()
        {

        }
    }
}