namespace Infrastructure.Entities.Enum
{
    public class CourseLevel : EnumType
    {
        public CourseLevel() { }
    }
}
