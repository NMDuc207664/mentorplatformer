namespace Infrastructure.Entities.Enum
{
    public class SessionFrequency : EnumType
    {
        public SessionFrequency() { }
    }
}