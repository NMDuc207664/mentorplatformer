namespace Infrastructure.Entities.Enum
{
    public class TypeOfResource : EnumType
    {
        public TypeOfResource() { }
    }
}