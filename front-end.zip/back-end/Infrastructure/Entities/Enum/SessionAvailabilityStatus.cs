﻿namespace Infrastructure.Entities.Enum
{
    public class SessionAvailabilityStatus : EnumType
    {
        public SessionAvailabilityStatus()
        {
        }
    }
}
