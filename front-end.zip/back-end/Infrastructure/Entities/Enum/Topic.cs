﻿namespace Infrastructure.Entities.Enum
{
    public class Topic : EnumType
    {
        public Topic()
        {
        }
    }
}
