﻿namespace Infrastructure.Entities.Enum
{
    public class AreaOfExpertise : EnumType
    {
        public AreaOfExpertise()
        {
        }
    }
}
