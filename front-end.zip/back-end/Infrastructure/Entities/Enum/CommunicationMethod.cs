namespace Infrastructure.Entities.Enum
{
    public class CommunicationMethod : EnumType
    {
        public CommunicationMethod() { }
    }
}