namespace Infrastructure.Entities.Enum
{
    public class Availability : EnumType
    {
        public Availability() { }

    }
}