namespace Infrastructure.Entities.Enum
{
    public class SessionDuration : EnumType
    {
        public SessionDuration() { }
    }
}