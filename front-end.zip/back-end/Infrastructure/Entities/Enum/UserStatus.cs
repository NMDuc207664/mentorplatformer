
namespace Infrastructure.Entities.Enum
{
    public class UserStatus : EnumType
    {
        public UserStatus() { }
    }
}