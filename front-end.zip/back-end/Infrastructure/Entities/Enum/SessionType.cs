﻿namespace Infrastructure.Entities.Enum
{
    public class SessionType : EnumType
    {
        public SessionType()
        {
        }
    }
}
