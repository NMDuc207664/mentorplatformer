namespace Infrastructure.Entities.Enum
{
    public class ResourceCategory : EnumType
    {
        public ResourceCategory() { }
    }
}