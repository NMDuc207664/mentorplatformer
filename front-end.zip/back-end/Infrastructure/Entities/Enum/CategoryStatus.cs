namespace Infrastructure.Entities.Enum
{
    public class CategoryStatus : EnumType
    {
        public CategoryStatus() { }
    }
}
