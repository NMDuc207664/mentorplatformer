namespace ApplicationCore.Constants
{
    public static class DatetimeFormat
    {
        public static readonly string dayFormat = "yyyy-MM-dd";
        public static readonly string hourFormat = "HH:mm";
    }
}
