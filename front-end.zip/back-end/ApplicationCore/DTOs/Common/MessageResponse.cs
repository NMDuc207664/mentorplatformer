﻿namespace ApplicationCore.DTOs.Common;

public class MessageResponse
{
    public required string Message { get; set; }
}
