namespace ApplicationCore.DTOs.Common
{
    public class FailResponse
    {
        public required string Message { get; set; }
    }
}
