﻿namespace ApplicationCore.DTOs.Requests.Authenticates;

public class ForgotPasswordRequest
{
    public required string Email { get; set; }
}
