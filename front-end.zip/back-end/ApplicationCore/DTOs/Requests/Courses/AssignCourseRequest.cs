﻿namespace ApplicationCore.DTOs.Requests.Courses;

public class AssignCourseRequest
{
    public Guid MentorId { get; set; }
}
