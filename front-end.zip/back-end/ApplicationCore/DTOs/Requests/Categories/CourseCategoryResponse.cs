using ApplicationCore.DTOs.Common;

namespace ApplicationCore.DTOs.Requests.Categories
{
    public class CourseCategoryResponse : BaseResponse
    {
        public CourseCategoryResponse() { }
    }
}
