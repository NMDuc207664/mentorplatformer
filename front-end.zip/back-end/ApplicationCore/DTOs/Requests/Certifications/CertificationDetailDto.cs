﻿namespace ApplicationCore.DTOs.Requests.Certifications
{
    public class CertificationDetailDto
    {
        public string CertificationName { get; set; } = string.Empty;
        public string IssuingOrganization { get; set; } = string.Empty;
    }
}
