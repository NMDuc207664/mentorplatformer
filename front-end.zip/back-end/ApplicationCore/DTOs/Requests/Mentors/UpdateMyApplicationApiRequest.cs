﻿namespace ApplicationCore.DTOs.Requests.Mentors
{
    public class UpdateMyApplicationApiRequest : BaseMentorApplicationApiRequest
    {
        public UpdateMyApplicationApiRequest()
        {
        }
    }
}
