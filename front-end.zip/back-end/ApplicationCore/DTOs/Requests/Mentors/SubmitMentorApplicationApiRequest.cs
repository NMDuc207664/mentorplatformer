namespace ApplicationCore.DTOs.Requests.Mentors
{
    public class SubmitMentorApplicationApiRequest : BaseMentorApplicationApiRequest
    {
        public SubmitMentorApplicationApiRequest()
        {
        }
    }
}
