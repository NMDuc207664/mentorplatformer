namespace ApplicationCore.DTOs.Requests.Users
{
    public class UpdateUserStatusRequestDto
    {
    }
}