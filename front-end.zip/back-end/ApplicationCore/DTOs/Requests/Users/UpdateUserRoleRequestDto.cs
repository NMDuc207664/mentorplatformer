namespace ApplicationCore.DTOs.Requests.Users
{
    public class UpdateUserRoleRequestDto
    {
        public int RoleId { get; set; }
    }
}
