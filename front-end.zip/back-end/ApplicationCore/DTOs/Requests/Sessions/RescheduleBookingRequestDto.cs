﻿namespace ApplicationCore.DTOs.Requests.Sessions
{
    public class RescheduleBookingRequestDto
    {
        public Guid NewMentorTimeAvailableId { get; set; }
    }
}
