namespace ApplicationCore.DTOs.Responses.Dashboards.Learners
{
    public class LearnerDashboardCompletion
    {
        public int LearningProgress { get; set; }
    }
}
