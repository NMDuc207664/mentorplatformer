namespace ApplicationCore.DTOs.Responses.Dashboards.Learners
{
    public class LearnerDashboardMentor
    {
        public int NumberOfMentors { get; set; }
    }
}
