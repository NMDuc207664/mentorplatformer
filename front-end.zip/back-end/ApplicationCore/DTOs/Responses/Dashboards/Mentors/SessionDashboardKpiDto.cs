﻿namespace ApplicationCore.DTOs.Responses.Dashboards.Mentors
{
    public class SessionDashboardKpiDto
    {
        public int SessionsThisMonth { get; set; }
        public int SharedResources { get; set; }
        public int LifetimeLearners { get; set; }
    }
}
