﻿namespace ApplicationCore.DTOs.Responses.Users;

public class MentorFilterResponse
{
    public Guid Id { get; set; }
    public string FullName { get; set; } = string.Empty;
}
