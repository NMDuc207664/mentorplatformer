namespace ApplicationCore.DTOs.Responses.Resources
{
    public class ResourceLinkResponse
    {
        public string Url { get; set; } = string.Empty;
    }
}