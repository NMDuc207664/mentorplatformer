﻿namespace ApplicationCore.DTOs.Responses.Sessions
{
    public class CreatedBookingResponseDto
    {
        public Guid Id { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
