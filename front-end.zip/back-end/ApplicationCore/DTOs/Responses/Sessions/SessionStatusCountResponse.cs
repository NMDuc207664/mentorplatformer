namespace ApplicationCore.DTOs.Responses.Sessions
{
    public class SessionStatusCountResponse
    {
        public int UpcomingSessionCount { get; set; }
        public int PastSessionCount { get; set; }
    }
}