﻿namespace ApplicationCore.DTOs.Responses.Sessions
{
    public class UpdateBookingResponseDto
    {
        public Guid Id { get; set; }
        public int StatusId { get; set; }
    }
}
