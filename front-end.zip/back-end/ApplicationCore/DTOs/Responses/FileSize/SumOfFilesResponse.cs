namespace ApplicationCore.DTOs.Responses.FileSize
{
    public class SumOfFilesResponse
    {
        public double Size { get; set; } = 0;
    }
}