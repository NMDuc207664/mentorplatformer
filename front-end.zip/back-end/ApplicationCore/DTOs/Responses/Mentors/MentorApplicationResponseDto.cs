namespace ApplicationCore.DTOs.Responses.Mentors
{
    public class MentorApplicationResponseDto : BaseMentorApplicationResponse
    {
        public MentorApplicationResponseDto()
        {
        }
    }
}
