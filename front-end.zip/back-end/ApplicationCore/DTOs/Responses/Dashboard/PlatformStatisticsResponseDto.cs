namespace ApplicationCore.DTOs.Responses.Dashboard
{
    public class PlatformStatisticsResponseDto
    {
        public double MentorRetention { get; set; }
        public double ResourceDownloads { get; set; }
        public int NewUsers30d { get; set; }
    }
}